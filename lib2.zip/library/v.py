import pickle
class Login:
	def __init__(self):
		self.name="akt1234"
		self.password="1@34"
c=Login()
with open("Login.pkl","wb") as f:
	pickle.dump(c,f)