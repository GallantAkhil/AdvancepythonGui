import sys
import pickle
from books import *
from students import *
from Faculty import *
isbn = sys.argv[1]
it = sys.argv[2]
id1 = sys.argv[3]
obj = None
kobj = None
k1 = 0
if it == 'Student':
	with open('student.pkl','rb') as f:
		obj = pickle.load(f)
		for i in obj:
			if i.id == id1:
				with open('books.pkl','rb') as p:
					kobj = pickle.load(p)
					for j in kobj:
						if j.isbn == isbn:
							j.quantity+=1
							p=i.books.index(j.name)
							i.books.pop(p)
							i.date.pop(p)
	with open('student.pkl','wb') as f:
		pickle.dump(obj,f)
	with open('books.pkl','wb') as p:
		pickle.dump(kobj,p)
else:
	with open('Faculty.pkl','rb') as f:
		obj = pickle.load(f)
		for i in obj:
			if i.id == id1:
				with open('books.pkl','rb') as p:
					kobj = pickle.load(p)
					for j in kobj:
						if j.isbn == isbn:
							j.quantity+=1
							p=i.books.index(j.name)
							i.books.pop(p)
							i.date.pop(p)
	with open('Faculty.pkl','wb') as f:
		pickle.dump(obj,f)
	with open('books.pkl','wb') as p:
		pickle.dump(kobj,p)