class Student:
	def __init__(self,name,branch,year):
		cnt=0
		self.name=name
		self.branch=branch
		self.year=year
		with open('count.txt','r') as f:
			cnt=int(f.read())
			cnt+=1
		self.id=str(cnt)+year+branch
		with open('count.txt','w') as f:
			f.write(str(cnt))
		self.Fine='0'
		self.books=[]
		self.date=[]
		