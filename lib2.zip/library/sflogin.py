import sys
import pickle
from books import *
from students import *
from datetime import *
name = sys.argv[1]
it = sys.argv[2]
id1 = sys.argv[3]
d="No Member Found"
def days_between(d1, d2):
    d1 = datetime.strptime(d1, "%d/%m/%y")
    d2 = datetime.strptime(d2, "%d/%m/%y")
    return abs((d2 - d1).days)
if it == "Student":
	with open('student.pkl','rb') as f:
		obj = pickle.load(f)
		for i in obj:
			if i.name == name:
				if i.id == id1:
					fine=0
					q=" "
					d = "Name: "+i.name+"\nuID: "+i.id+"\nBranch: "+i.branch+"\nYear of study: "+i.year+"\n"
					for j in i.books:
						k=i.books.index(j)
						q+=j+" "+i.date[k]+"\n"
						date1=i.date[k]
						date2 = date.today()
						g=days_between(date1,date2.strftime("%d/%m/%y"))
						if g > 10:
							g=g-10
							fine += g*5
					d+="Fine: "+str(fine)+"\nBooks: "+q
else:
	with open('faculty.pkl','rb') as f:
		obj = pickle.load(f)
		for i in obj:
			if i.name == name:
				if i.id == id1:
					fine=0
					q=" "
					d = "Name: "+i.name+"\nuID: "+i.id+"\nBranch: "+i.branch
					for j in i.books:
						k=i.books.index(j)
						q+=j+" "+i.date[k]+"\n"
						date1=i.date[k]
						date2 = date.today()
						g=days_between(date1,date2.strftime("%d/%m/%y"))
						if g > 10:
							g=g-10
							fine += g*5
					d+="\nFine: "+str(fine)+"\nBooks: "+q
with open("akhil.txt","w") as f:
	f.write(d)